function filterActivities() {
    //get the activityName of the selected activity from the filter dropdown
    var activityName = document.getElementById('activityName').value
    console.log(activityName);
    //construct the URL and redirect to it
    // let a = encodeURI(activityName);
    // console.log(a);
    window.location = '/filter/' + encodeURI(activityName);
}

