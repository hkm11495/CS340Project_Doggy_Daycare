SELECT activitiesLookUp.activityName, activities.activityDate,activities.activityTime, activities.leadActivityCoordinator, dogs.dogName FROM activitiesLookUp
INNER JOIN activities ON activitiesLookUp.activityLookUpID=activities.activityLookUpID
LEFT JOIN dogActivities ON activities.activityID=dogActivities.activityID
LEFT JOIN dogs ON dogActivities.dogID=dogs.dogID;

SELECT dogs.dogName, activitiesLookUp.activityName FROM activitiesLookUp
INNER JOIN activities ON activitiesLookUp.activityLookUpID=activities.activityLookUpID
INNER JOIN dogActivities ON activities.activityID=dogActivities.activityID
INNER JOIN dogs ON dogActivities.dogID=dogs.dogID;