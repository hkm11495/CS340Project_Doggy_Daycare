const baseURL='http://flip3.engr.oregonstate.edu:5223/getDogs';
const baseURL3='http://flip3.engr.oregonstate.edu:5223/getStaysActivities';
const dd2=document.getElementById('dropDown2');
const idInputs=document.getElementsByName('dogID');
document.addEventListener('DOMContentLoaded', getSelected("custDrop", "customerID", baseURL,createDropDown));
document.addEventListener('DOMContentLoaded', getSelected("dropDown2", "dogID",baseURL3 , createTable));


//Creates drop down menu from response in the ajax call
function createDropDown(rows)
{
	while (dd2.firstChild) 
	{
		dd2.removeChild(dd2.lastChild); 
	}
	console.log(rows);
	var temp=[];
	for (var i=0;i<rows.length;i++)
	{
		temp=rows[i];
		console.log(temp)
		console.log(temp.dogID)	
		var id=temp.dogID.toString();
		var name=temp.dogName.toString();
		var breed=temp.breed.toString();
		var age=temp.age.toString();
		var opt=document.createElement("option");
		opt.setAttribute('id', temp.dogID);
		opt.setAttribute('value', temp.dogID);
		//combines all data into a single option
		opt.textContent=(name + ", " +breed + ", " + age );
		dd2.appendChild(opt);	
	}
}



//when a change is made in a dropdown bar, send an ajax request to retrieve the data of the newly selected item
function getSelected(selectID, objectKey,url ,callback)
{
	document.getElementById(selectID).addEventListener('click',(event)=>
	{
		var request = new XMLHttpRequest();
		var val=document.getElementById(selectID.toString()).value;
		var context={};
		context[objectKey]=val;
		request.open("POST", url, true);
		request.setRequestHeader('Content-Type', 'application/json');
		request.addEventListener('load',function()
		{
			if(request.status >= 200 && request.status < 400)
			{

				deleteTable();	
				deleteTable2();	
			
				var response = JSON.parse(request.responseText);
				//make drop down appear
				dd2.style.display="block";
				console.log(response.rows);
				//create drop down menu from retrieved data
				callback(response.rows);
			} 
			else 
			{
			  console.log(request.status);
			}
		});
		//console.log(JSON.stringify(context));
		request.send(JSON.stringify(context));
		event.preventDefault;
	});
}

function createTable(rows)
{
	console.log(rows)
	//var formInner=document.createElement("Form");
	var table = document.createElement("TABLE");

	//document.body.appendChild(formInner);
	table.setAttribute("id", "table1");
	document.getElementById("tableRow1").appendChild(table);
	document.getElementById("table1").style.border="thin solid #0000FF";
	createHeader();
	if (rows.length==0)
	{
		createTable2(rows)
		return;
	}
	var key=Object.keys(rows[0]);
	var activitiesIDArray=[];
	for (var p in rows)
	{
		var item=rows[p];
		var nextLoop=false;
		//check if ID already exists in table
		for (var i=0;i<activitiesIDArray.length;i++)
		{
			if (item[key[0]]==activitiesIDArray[i])
			{
				nextLoop=true;
			}
		}
		if (nextLoop == false)
		{
			activitiesIDArray.push(item[key[0]])
			var row=document.createElement("TR");
			table.appendChild(row);
			row.setAttribute("id",p);
			//Add Cells for Data
			for (var i=1;i<6;i++)
			{
				var cell=createCells(p,item[key[i]]);
				row.appendChild(cell);
			}	
		}
	}
	createTable2(rows)
}

function createTable2(rows)
{
	//var formInner=document.createElement("Form");
	var table = document.createElement("TABLE");

	//document.body.appendChild(formInner);
	table.setAttribute("id", "table2");
	document.getElementById("tableRow2").appendChild(table);
	document.getElementById("table2").style.border="thin solid #0000FF";
		
	createHeader2();
	if (rows.length==0)
	{
		return;
	}
	var stayIDArray=[];
	var key=Object.keys(rows[0]);
	for (var p in rows)
	{
		var item=rows[p];
		var nextLoop=false;
		//check if ID already exists in table
		for (var i=0;i<stayIDArray.length;i++)
		{
			if (item[key[6]]==stayIDArray[i])
			{
				nextLoop=true;
			}
		}
		if (nextLoop == false)
		{
			stayIDArray.push(item[key[6]])
		
			var row=document.createElement("TR");
			table.appendChild(row);
			row.setAttribute("id",p);
			
			//Add Cells for Data
			for (var i=7;i<12;i++)
			{	
				//convert bool to overnight/daycare
				if (i==7)
				{
					if (item[key[7]]==1)
					{
						var cell=createCells(p,"overnight");
					}
					else if (item[key[7]]==0)
					{
						var cell=createCells(p,"daycare");
					}
					else
					{
						var cell=createCells(p,item[key[7]]);
					}
					row.appendChild(cell);
				}
				else
				{
					var cell=createCells(p,item[key[i]]);
					row.appendChild(cell);	
				}
			}	
		}
	}
}




//Add header for create table
function createHeader()
{
		var hrow=document.createElement("TR");
		document.getElementById('table1').appendChild(hrow);
		var hcell=createCells('header',"Activity Name");
		hrow.appendChild(hcell);
		hcell=createCells('header',"Activity Date");
		hrow.appendChild(hcell);
		hcell=createCells('header',"Activity Time");
		hrow.appendChild(hcell);
		hcell=createCells('header',"Activity Coordinator");
		hrow.appendChild(hcell);
		hcell=createCells('header',"Activity Cost ($)");
		hrow.appendChild(hcell);
		hrow.style.fontWeight="bold";
}

//Add header for create table
function createHeader2()
{
		var hrow=document.createElement("TR");
		document.getElementById('table2').appendChild(hrow);
		var hcell=createCells('header',"Stay Type");
		hrow.appendChild(hcell);
		hcell=createCells('header',"Stay Start Date");
		hrow.appendChild(hcell);
		hcell=createCells('header',"Stay End Date");
		hrow.appendChild(hcell);
		hcell=createCells('header',"Stay Duration (Days)");
		hrow.appendChild(hcell);
		hcell=createCells('header',"Stay Cost ($)");
		hrow.appendChild(hcell);
		hrow.style.fontWeight="bold";
}

//Deletes Table
function deleteTable()
{	console.log("deleting table");
	if (document.getElementById('table1')!= 'undefined' && document.getElementById('table1') != null )
	{
		var allRows=document.getElementById('table1').children;
		for(var p in allRows)
		{
			var cells=allRows[p].children;
			//remove text
			for (var k in cells)
			{
				cells[k].textContent='';
			}
			while (allRows[p].firstChild) 
			{
				allRows[p].removeChild(allRows[p].lastChild);
			}
		}
		var tbl= document.getElementById('table1');
		while (tbl.firstChild) 
		{
			tbl.removeChild(tbl.lastChild);
		}
			tbl.parentNode.removeChild(tbl);
	}
	else
	{
		console.log("table not found");
		return;
	}
}
//Deletes Table
function deleteTable2()
{	console.log("deleting table");
	if (document.getElementById('table2')!= 'undefined' && document.getElementById('table2') != null )
	{
		var allRows=document.getElementById('table2').children;
		for(var p in allRows)
		{
			var cells=allRows[p].children;
			//remove text
			for (var k in cells)
			{
				cells[k].textContent='';
			}
			while (allRows[p].firstChild) 
			{
				allRows[p].removeChild(allRows[p].lastChild);
			}
		}
		var tbl= document.getElementById('table2');
		while (tbl.firstChild) 
		{
			tbl.removeChild(tbl.lastChild);
		}
			tbl.parentNode.removeChild(tbl);
	}
	else
	{
		console.log("table not found");
		return;
	}
}

function createCells(inputID,itemText)
{
	var cellT=document.createElement("TD");
	celltext=document.createTextNode(itemText);
	cellT.appendChild(celltext);
	cellT.style.border="thin solid #0000FF";
	return cellT;
}
