
/*NEET TO FIX PORT NUMBERS BEFORE SUBMITTING*/
var dogIDs=[];
var ownerIDs=[];
var arrayCheckOwner=0;
var arrayCheckDog=0;
var owners=[];
var ownerForms=document.getElementsByName('custForm');
var dogForms=document.getElementsByName('dogForm');
submitBut=document.getElementById('submitNew');
document.addEventListener('DOMContentLoaded',sendformInfo);



//Submit button is clicked
function sendformInfo()
{	
	//add event listener
	document.getElementById('submitNew').addEventListener('click', function(event){
	ownerIDs=[];
	dogIDs=[];
	owners=[];
	for (let i=0; i< ownerForms.length; i++)
	{
		var current=ownerForms[i];
		arrayCheckOwner++;
		getFormDataO(current,'http://flip3.engr.oregonstate.edu:5223/newCustomer',arrayCheckOwner , processFormOwners);
	}
			
		console.log(ownerIDs);
		console.log(dogIDs);
		
	});

}

//loop to access form contents for all of the dogs
function getDogs()
{
	for (let i=0; i< dogForms.length; i++)
	{
		let current=dogForms[i];
		arrayCheckDog++;
		getFormDataD(current,'http://flip3.engr.oregonstate.edu:5223/newDog', arrayCheckDog,processFormDogs);
	}
}

//getID of owners just submitted and store in array. call getDogs
function processFormOwners(id)
{
	ownerIDs.push(id);
	console.log(ownerIDs);
	console.log(arrayCheckOwner);
	if (arrayCheckOwner ==0)
	{
		getDogs();
	}
}

//rocess dog forms content
function processFormDogs(id)
{
	dogIDs.push(id);
	console.log(dogIDs);
	if (arrayCheckDog ==0)
	{
		combineDogsCustomers(dogIDs,ownerIDs);
	}
}

//populate dogIDs and customerIDs into an array
function combineDogsCustomers(dogArray, customerArray)
{
	for (var i=0; i<dogArray.length; i++)
	{
		for (var j=0; j<customerArray.length; j++)
		{
						//dogID      //customerID
		owners.push({'dogID':dogArray[i], 'customerID':customerArray[j]});
		}
	}
	console.log(owners);
	submitOwners(owners);
}

//Send owner data to backend
function getFormDataO(Forms, baseURL,counter ,callback)
{
			var inputs =Forms.elements;
			var formContent={};
			//assign form keys and values to object
			
			for (var j=0; j<inputs.length;j++)
			{
				formContent[inputs[j].name]=(inputs[j].value);
			}
			//create asynchronous request
			var request = new XMLHttpRequest();
			request.open("POST", baseURL, true);
			request.setRequestHeader('Content-Type', 'application/json');
			request.addEventListener('load',function()
			{
				if(request.status >= 200 && request.status < 400)
				{
				 
					var response = JSON.parse(request.responseText);
					//array.push(response);
					arrayCheckOwner--;
					callback(response);
				} 
				else 
				{
				  console.log(request.status);
				}
	      });
			console.log(JSON.stringify(formContent))
			request.send(JSON.stringify(formContent));
			event.preventDefault();
}

//send dog information to back end
function getFormDataD(Forms, baseURL,counter ,callback)
{
			var inputs =Forms.elements;
			var formContent={};
			//assign form keys and values to object
			
			for (var j=0; j<inputs.length;j++)
			{
				formContent[inputs[j].name]=(inputs[j].value);
			}
			//create asynchronous request
			var request = new XMLHttpRequest();
			request.open("POST", baseURL, true);
			request.setRequestHeader('Content-Type', 'application/json');
			request.addEventListener('load',function()
			{
				if(request.status >= 200 && request.status < 400)
				{
				 
					var response = JSON.parse(request.responseText);
					//array.push(response);
					arrayCheckDog--;
					callback(response);
				} 
				else 
				{
				  console.log(request.status);
				}
	      });
			console.log(JSON.stringify(formContent));
			request.send(JSON.stringify(formContent));
			event.preventDefault();
}

// send dogID and customerIDs into owners
function submitOwners(content)
{
	var request = new XMLHttpRequest();
			request.open("POST", 'http://flip3.engr.oregonstate.edu:5223/owners', true);
			request.setRequestHeader('Content-Type', 'application/json');
			request.addEventListener('load',function()
			{
				if(request.status >= 200 && request.status < 400)
				{
					console.log('all data submitted');
				} 
				else 
				{
				  console.log(request.status);
				}
	      });
			console.log(JSON.stringify(content));
			request.send(JSON.stringify(content));
			event.preventDefault();
}

