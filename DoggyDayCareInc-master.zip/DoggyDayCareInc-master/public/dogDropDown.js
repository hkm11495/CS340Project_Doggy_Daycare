//const baseURL='http://flip3.engr.oregonstate.edu:5223/dogSignUp';
const baseURL2='http://flip3.engr.oregonstate.edu:5223/enrollInActivity';
const baseURL3='http://flip3.engr.oregonstate.edu:5223/getActivities';
const baseURL4='http://flip3.engr.oregonstate.edu:5223/getDogs';
const dd2=document.getElementById('dropDown2');
const idInputs=document.getElementsByName('dogID');
document.addEventListener('DOMContentLoaded', getSelected("custDrop", "customerID", baseURL4,createDropDown));
document.addEventListener('DOMContentLoaded', addIdsToForms);
document.addEventListener('DOMContentLoaded', getSelected("dropDown3", "activityName",baseURL3 , createTable));
//document.addEventListener('DOMContentLoaded', makeHidden);
//const submitButDogIDs=document.getElementById('submitDogID');


//Creates drop down menu from response in the ajax call
function createDropDown(rows)
{
	while (dd2.firstChild) 
	{
		dd2.removeChild(dd2.lastChild); 
	}
	console.log(rows);
	var temp=[];
	for (var i=0;i<rows.length;i++)
	{
			temp=rows[i];
			var id=temp.dogID.toString();
			var name=temp.dogName.toString();
			var breed=temp.breed.toString();
			var age=temp.age.toString();
			var opt=document.createElement("option");
			opt.setAttribute('id', temp.dogID);
			opt.setAttribute('value', temp.dogID);
			//combines all data into a single option
			opt.textContent=(name + ", " +breed + ", " + age );
			dd2.appendChild(opt);
			
	}
	//makes this drop down appear
	//submitButDogIDs.style.display="block";
}


/*make objects hidden on page load
function makeHidden()
{
	dd2.style.display="none";
	submitButDogIDs.style.display="none";
}
*/
//when submit button is clicked populate the hidden id inputs for dog ID in other forms in the page
function addIdsToForms()
{
	dd2.addEventListener('click', function()
	{
		for (var i=0; i< idInputs.length; i++)
		{
			idInputs[i].value=dd2.options[dd2.selectedIndex].value;
			console.log(idInputs[i].value);
		}
		var dogInfoP=document.querySelectorAll("#SelectedDog");
		for (var i in dogInfoP)
		{
			dogInfoP[i].textContent=(dd2.options[dd2.selectedIndex].innerHTML).toString();
		}
	});	
}

//when a change is made in a dropdown bar, send an ajax request to retrieve the data of the newly selected item
function getSelected(selectID, objectKey,url ,callback)
{
	document.getElementById(selectID).addEventListener('click',(event)=>
	{
		var request = new XMLHttpRequest();
		var val=document.getElementById(selectID.toString()).value;
		var context={};
		context[objectKey]=val;
		request.open("POST", url, true);
		request.setRequestHeader('Content-Type', 'application/json');
		request.addEventListener('load',function()
		{
			if(request.status >= 200 && request.status < 400)
			{
				if (selectID=="dogName")
				{
					submitButDogIDs.style.display="none";
				}
				if (selectID=="dropDown3")
				{
					deleteTable();
				}
				var response = JSON.parse(request.responseText);
				//make drop down appear
				dd2.style.display="block";
				//create drop down menu from retrieved data
				callback(response.rows);
			} 
			else 
			{
			  console.log(request.status);
			}
		});
		//console.log(JSON.stringify(context));
		request.send(JSON.stringify(context));
		event.preventDefault;
	});
}

function createTable(rows)
{
	//var formInner=document.createElement("Form");
	var table = document.createElement("TABLE");
	//document.body.appendChild(formInner);
	table.setAttribute("id", "table1");
	document.getElementById("form3").appendChild(table);
	document.getElementById("table1").style.border="thin solid #0000FF";
	createHeader();
	if (rows.length==0)
	{
		console.log('rows length is zero, table wont be made')
		return;
	}	
	var key=Object.keys(rows[0]);
	for (var p in rows)
	{
		var row=document.createElement("TR");
		table.appendChild(row);
		
		var item=rows[p];
		row.setAttribute("id",p);
		
		//Add Cells for Data
		for (var i=0;i<4;i++)
		{
			var cell=createCells(p,item[key[i]]);
			//hide id column
			if (i==0)
			{
				cell.style.display='none';
			}
			row.appendChild(cell);
		}
		//Add Buttons
		var cell=createCells(p,"");
		row.appendChild(cell);
		//var updateBut=createUpdateButton(p);
		//cell.appendChild(updateBut);
		
		//var cell=createCells(p,"");
		//row.appendChild(cell);
		//var deleteBut=createDeleteButton(p);
		//cell.appendChild(deleteBut);
		var addBut=createAddButton(p);
		cell.appendChild(addBut);
	}
	setAddButtons();
	//setUpButtons();
	//setDeleteButtons();
}


function createHeader()
{
			//add header
		var hrow=document.createElement("TR");
		document.getElementById('table1').appendChild(hrow);
		var hcell=createCells('header',"ID");
		hcell.style.display='none';
		hrow.appendChild(hcell);
		hcell=createCells('header',"Activity Date");
		hrow.appendChild(hcell);
		hcell=createCells('header',"Activity Time");
		hrow.appendChild(hcell);
		hcell=createCells('header',"Activity Coordinator");
		hrow.appendChild(hcell);
		hrow.style.fontWeight="bold";
}

//Deletes Table
function deleteTable()
{	console.log("deleting table");
	if (document.getElementById('table1')!= 'undefined' && document.getElementById('table1') != null )
	{
		var allRows=document.getElementById('table1').children;
		for(var p in allRows)
		{
			var cells=allRows[p].children;
			//remove text
			for (var k in cells)
			{
				cells[k].textContent='';
			}
			while (allRows[p].firstChild) 
			{
				allRows[p].removeChild(allRows[p].lastChild);
			}
		}
		var tbl= document.getElementById('table1');
		while (tbl.firstChild) 
		{
			tbl.removeChild(tbl.lastChild);
		}
			tbl.parentNode.removeChild(tbl);
	}
	else
	{
		console.log("table not found");
		return;
	}
	
}


function createCells(inputID,itemText)
{
	var cellT=document.createElement("TD");
	celltext=document.createTextNode(itemText);
	cellT.appendChild(celltext);
	cellT.style.border="thin solid #0000FF";
	return cellT;
}

function createAddButton(inputID)
{
	var newSubmit=document.createElement("button");
	newSubmit.setAttribute("id", inputID);
	newSubmit.setAttribute("name", "add");
	newSubmit.innerHTML='Enroll';
	return newSubmit;
};

function setAddButtons()
{	
	const addButtons = document.querySelectorAll('button[name="add"]');
	//Adds event handler to all delete buttons
	addButtons.forEach(function(currentBtn){
	currentBtn.addEventListener('click', 
	function(event)
	{
	  event.preventDefault
	  selectActivity(this.id, this.parentElement.parentElement)
	  //handleEvent(this.id,this.parentElement.parentElement,"addForm")
	//ajax call to submit add ID
	  },false);
	})
};

//post to select Dog
function selectActivity(buttonID, tableRow)
{
	var children=tableRow.children;
	var data={};
	data["activityID"]=children[0].textContent;
	data["dogID"]=idInputs[0].value;
	var request = new XMLHttpRequest();
	request.open("POST", baseURL2, true);
	request.setRequestHeader('Content-Type', 'application/json');
	
	request.addEventListener('load',function()
	{
		if(request.status >= 200 && request.status < 400)
		{
			console.log('submit was successful')
		} 
		else 
		{
		  console.log(request.status);
		}
	});
	console.log(JSON.stringify(data));
	request.send(JSON.stringify(data));
	event.preventDefault();
	console.log(JSON.stringify(data));
}






