//FILE FOR INSERTIND DATA FOR NEW CUSTOMER PAGE
/*
var mysql = require('./dbcon.js');
var app = express();
var bodyParser = require('body-parser');
const CORS=require('cors');

var handlebars = require('express-handlebars').create({defaultLayout:'main'});
app.set('mysql', mysql);
app.engine('handlebars', handlebars.engine);
app.use(bodyParser.urlencoded({extended:false}));
app.use(CORS());
app.set('view engine', 'handlebars');
app.set('port', process.argv[2]);

app.use(bodyParser.json());
app.use(function (req, res, next) {
res.setHeader('Access-Control-Allow-Origin', '*');
res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
res.setHeader('Access-Control-Allow-Credentials', true);
next();
});
*/


module.exports=function(){

const express = require('express');
const app = express();
function getCustomerID(fName, lName, callback) 
{
		mysql.pool.query("SELECT customerID FROM customers WHERE firstName=? and lastName=?", [fName, lName], (err, result)=>
			{
				if(err)
				{
					callback(err);
				}
				else
				{
					callback(null, result[0].customerID)
				}
		});
}

//returns dogID 
function getdogID(name, age, breed ,callback) 
{
		mysql.pool.query("SELECT dogID FROM dogs WHERE dogName=? and age=? and breed=?", [name, age, breed], (err, result)=>
			{
				if(err)
				{
					callback(err);
				}
				else
				{
					callback(null, result[0].dogID)
				}
		});
}


//POST request the inserts data into customers and customersAddress databases
app.post('/newCustomer', function(req, res){
	var mysql = req.app.get('mysql');
	var custID='';
	console.log("inside post")
	var sqlInsert = "INSERT INTO customers (firstName, lastName, phoneNumber, email) VALUES (?,?,?,?)";
	var inserts1 = [req.body.firstName, req.body.lastName, req.body.phoneNumber, req.body.email];
	var sqlInsert2 ="INSERT INTO customersAddress (customerID, address, city, state, zipcode) VALUES (?,?,?,?,?)"
	var sql1 = mysql.pool.query(sqlInsert,inserts1,function(error, results, fields){
		if(error){
			res.write(JSON.stringify(error));
			res.end();
		}else{
			//Get the customer ID of the user just submitted
			getCustomerID(req.body.firstName, req.body.lastName, function(err, data)
			{
				if (err)
				{
					console.log(err);
					res.end();
				}
				else
				{
					custID=data;
					
					var inserts2 = [custID, req.body.address, req.body.city, req.body.state, req.body.zipcode];
					//insert customer Address
					var sql2 = mysql.pool.query(sqlInsert2,inserts2,function(error, results, fields){
						if(error)
						{
							res.write(JSON.stringify(error));
							res.end();
						}
						else
						{
							res.json(custID);
						}

					});
				}
			});
		}
	});
});



//POST request the inserts data into dogs
app.post('/newDog', function(req, res){
	var mysql = req.app.get('mysql');
	var custID='';
	console.log("inside post dogs")
	var sqlInsert = "INSERT INTO dogs (dogName, age, breed) VALUES (?,?,?)";
	var inserts1 = [req.body.dogName, req.body.age, req.body.breed];
	var sql1 = mysql.pool.query(sqlInsert,inserts1,function(error, results, fields){
		if(error){
			res.write(JSON.stringify(error));
			res.end();
		}else{
			//Get the customer ID of the user just submitted
			getdogID(req.body.dogName, req.body.age, req.body.breed, function(err, data)
			{
				if (err)
				{
					console.log(err);
					res.end();
				}
				else
				{
					dogID=data;
					res.json(dogID);
				}
			});
		}
	});
});

//combine insert for owners table 
app.post('/owners', function(req, res){
	var mysql = req.app.get('mysql');
	var array=[]
	var data=req.body;
	for (var i=0; i < data.length; i++)
	{
		console.log(data[i]);
		array.push([data[i].customerID, data[i].dogID]);
	}
	console.log(array);
	var sqlInsert="INSERT INTO owners (customerID, dogID) VALUES ?";
	
	var sql1 = mysql.pool.query(sqlInsert,[array],function(error, results, fields){
		if(error){
			res.write(JSON.stringify(error));
			res.end();
		}else
		{
			res.json('owners data submitted');
		}
	});
});

return app;
}();
/*
// Render Errors
app.use(function(req,res){
  res.status(404);
  res.render('404');
});

app.use(function(err, req, res, next){
  console.error(err.stack);
  res.status(500);
  res.render('500');
});

app.listen(app.get('port'), function(){
  console.log('Express started on http://flip3.engr.oregonstate.edu:' + app.get('port') + '; press Ctrl-C to terminate.');
});

*/